import { TechrelService } from './../techrel.service';
import { Component, OnInit } from '@angular/core';
declare var $:any;

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  constructor(private api:TechrelService) { }
  single:any;
  AAA:number=1;

  allid:any;
  ngOnInit(): void {

   

    this.AAA;
    this.api.apiData().subscribe((res)=>{
      this.allid=res;
    })
  }

  dd(id:number){
      this.api.singleUserDate(id).subscribe((res)=>{
        this.single=res;
      })
  }

}
