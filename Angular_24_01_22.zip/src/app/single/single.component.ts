import { TechrelService } from './../techrel.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-single',
  templateUrl: './single.component.html',
  styleUrls: ['./single.component.css']
})
export class SingleComponent implements OnInit {

  constructor( private api:TechrelService, private actrout:ActivatedRoute) { }
  singData:any;
  ngOnInit(): void {
    this.api.singelUser(this.actrout.snapshot.params.id).subscribe((res)=>{
      this.singData=res;
      
    })
    this.singData;
    
  }

}
