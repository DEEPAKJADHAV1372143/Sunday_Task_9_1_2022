import { TestBed } from '@angular/core/testing';

import { TechrelService } from './techrel.service';

describe('TechrelService', () => {
  let service: TechrelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TechrelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
