import { TechrelService } from './techrel.service';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { HttpClientModule } from '@angular/common/http'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { ListComponent } from './list/list.component';
import { SingleComponent } from './single/single.component';
import { FormComponent } from './form/form.component';
import { LoginComponent } from './login/login.component';
import { EditformComponent } from './editform/editform.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ListComponent,
    SingleComponent,
    FormComponent,
    LoginComponent,
    EditformComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgxPaginationModule,
    ReactiveFormsModule
  ],
  providers: [TechrelService],
  bootstrap: [AppComponent]
})
export class AppModule { }
