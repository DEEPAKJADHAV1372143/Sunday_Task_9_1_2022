import { EditformComponent } from './editform/editform.component';
import { LoginComponent } from './login/login.component';
import { FormComponent } from './form/form.component';
import { SingleComponent } from './single/single.component';
import { ListComponent } from './list/list.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'about',component:AboutComponent},
  {path:'home',component:HomeComponent},
  {path:'list',component:ListComponent},
  {path:'single/:id',component:SingleComponent},
  {path:'form',component:FormComponent},
  {path:'edit/:id',component:EditformComponent},
  {path:'login',component:LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
