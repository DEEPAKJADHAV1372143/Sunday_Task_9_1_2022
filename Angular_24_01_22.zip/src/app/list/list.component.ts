import { TechrelService } from './../techrel.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  constructor(private api:TechrelService , private route:Router) { }
  UserList:any;
  ngOnInit(): void {
    this.api.listOfUser().subscribe((res)=>{
      this.UserList=res;
    })
  }

  second_page(no:number){
    this.route.navigate(['single',no]);
  }

}
