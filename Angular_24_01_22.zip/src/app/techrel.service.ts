import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TechrelService {

  constructor(private http:HttpClient) { }

  Insert_Data_My_api(data:any){
    return this.http.post('http://localhost:8000/insert',data);
  }
  Select_Data_Form_my_api(){
    return this.http.get("http://localhost:8000/select");
  }
  Delete_Data_Form_my_api(data:{id:any}){
    return this.http.post("http://localhost:8000/delete",data);
  }
  OneRd_Data_Form_my_api(data:{id:any}){
    return this.http.post("http://localhost:8000/oneRd",data);
  }
  Update_Data_Form_my_api(data:any){
    return this.http.post("http://localhost:8000/update",data);
  }


  apiData(){
    return this.http.get('https://jsonplaceholder.typicode.com/posts');
  }
  singleUserDate(id:number){
    return this.http.get('https://jsonplaceholder.typicode.com/posts/'+id);
  }
  listOfUser(){
    return this.http.get("https://jsonplaceholder.typicode.com/users");
  }
  singelUser(id:number){
    return this.http.get("https://jsonplaceholder.typicode.com/users/"+id);
  }
  formDataaip(data:any){
    return data;
     //return this.http.post("https://jsonplaceholder.typicode.com",data);
  }
}
