import { TechrelService } from './../techrel.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor( private formbuilder:FormBuilder, private api:TechrelService) { }

  formdata:any;
  ngOnInit(): void {
    this.formdata=this.formbuilder.group({
      username:[''],
      userpass:[''],
      useremail:['']
    });
  }

  sub(){
    this.api.Insert_Data_My_api(this.formdata.value).subscribe((res)=>{
      alert("insert");
    })
  }

}
