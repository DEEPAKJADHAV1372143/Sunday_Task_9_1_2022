import { TechrelService } from './../techrel.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-editform',
  templateUrl: './editform.component.html',
  styleUrls: ['./editform.component.css']
})
export class EditformComponent implements OnInit {

  constructor( private acctiveroute:ActivatedRoute,private formbluder:FormBuilder , private api:TechrelService) { }
 data:any;
 formData:any;
  submited:boolean=false;
  ngOnInit(): void {
    this.api.OneRd_Data_Form_my_api({id:this.acctiveroute.snapshot.params.id}).subscribe((res)=>{
      this.data=res;
    });
    this.formData =this.formbluder.group({
      name:[''],
      id:[''],
      email:[''],
      phone:['']
    });
  }

  noSubmit(){
    this.submited=true;
    this.api.Update_Data_Form_my_api(this.formData.value).subscribe((res)=>{
      alert("Updataed");
    });
  }

}
