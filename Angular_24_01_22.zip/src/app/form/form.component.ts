import { Router } from '@angular/router';
import { TechrelService } from './../techrel.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';


@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  constructor( private route:Router, private formbluder:FormBuilder , private api:TechrelService) { }
  formData:any;
  submited:boolean=false;
 newData:any;
oneData:any;
 myyData:any;
  ngOnInit(): void {

    this.api.Select_Data_Form_my_api().subscribe((res)=>{
      this.myyData=res;
    })
    this.formData =this.formbluder.group({
      name:[''],
      email:[''],
      phone:['']
    });
   this.oneData;
 this.newData;
  }

  delete(id:number){
   this.api.Delete_Data_Form_my_api({id}).subscribe((res)=>{

   });
  }


  Edit(id:number){
   this.route.navigate(['edit',id]);
   }

  noSubmit(){
    this.submited=true;
    this.api.Insert_Data_My_api(this.formData.value).subscribe((res)=>{
      alert("insert");
    });
  }

}
