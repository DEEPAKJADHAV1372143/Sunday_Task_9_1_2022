 const constant = {}
 
 constant.apiConstants = Object.freeze({
   GET_TOC_CONTENT : '/get_toc_content',
   CHECK_OUT_TOC_REPORT: '/check_out_toc_report', 
   IGR_AC_DETAILS: '/igr_ac_manager',
   KEY_GEN:'WV9?H*):QMgVh(Ath#J=BQ[Cz1~k](Ox`$fAJNdlREPN3ZTKXcR7Q(OYk"N+*`7',
   SALT:10
  });

  constant.catchClientError = (error,res) => {
   res.status(error.status || 500);
   res.json({
     errorMessage: error.message,
     error: error
   });
}

module.exports = constant;
  