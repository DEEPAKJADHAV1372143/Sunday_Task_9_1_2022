
module.exports = function(app, sequelize){
require('./tbl_contact_query')(app, sequelize)

}
