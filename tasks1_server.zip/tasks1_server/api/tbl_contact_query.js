
module.exports = function(app, sequelize){
    
    var initModels = require("../models/init-models");
    var models = initModels(sequelize);

    const bodyParser = require('body-parser');
    var nodemailer =require("nodemailer");
    app.use(bodyParser.json());
    const emailSender = require("../service/emailSender")
    var constants = require("../utils/apiConstants")
    var errorCatcher = constants.catchClientError  

    app.get('/tbl_contact_query', (req, res) => {
        models.tbl_contact_query.findAll({
          order: [
            ['id', 'DESC'],
        ]
        }).then((results)=>{
            res.send(200, results);
            console.log(results);
        });
    });

   app.get('/tbl_contact_query/:id', (req, res) => {
                models.tbl_contact_query.findAll({
                    where: {
                        id:req.params.id
                    }
                }).then((results) => {
                    res.json(200, results);
                });
     });

     
    app.post('/tbl_contact_query', (req, res) => {
        var db = req.body
        console.log(db);
        var date_now= new Date();
        models.tbl_contact_query.create({
              first_name:db.first_name,
              last_name:db.last_name,
              contact:db.contact,
              time_slot:db.time_slot,
              created_at:date_now,

        }).then(function(results) {
         res.json(results);
         console.log("data insert Successfully ..");
        }); 
    });


    app.put('/tbl_contact_query_d', (req, res) => {
    
    })

    app.get('/tbl_contact_query_del/:id', (req, res) => {
         models.tbl_contact_query.destroy({
           where: {
              id:req.params.id
           }
        }).then(function(rowDeleted){ 
          if(rowDeleted === 1){
             console.log('Deleted successfully');
           }
        }, function(err){
            console.log(err); 
        });
    });

        app.post('/tbl_contact_query_updated', (req, res) => {
        var db = req.body
        console.log(db);
        var date_now= new Date();
        models.tbl_contact_query.update({
             first_name:db.first_name,
              last_name:db.last_name,
              contact:db.contact,
              time_slot:db.time_slot,
              created_at:date_now,

        },{
            where: {
              id:db.id
           }
         }).then(function(results) {
         res.json(results);
         console.log("data Updated Successfully ..");
          
          
        }); 
    });

    app.delete('/tbl_contact_query', (req, res) => {
    
    })



}




