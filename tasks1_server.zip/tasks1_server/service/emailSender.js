
    var nodemailer = require('nodemailer');
    var handlebars = require('handlebars');
    var fs  = require('fs');
    var  path = require('path');
    const email = {}   

     email.sendEmail = async function  sendEmail (toEmail,fromEmail, subject,emailData,payment_mode) {
        const filePath = path.join(__dirname, '../templates/purchase_email.html');
        const source = fs.readFileSync(filePath, 'utf-8').toString();
        const template = handlebars.compile(source);
        const replacements = {
          Full_name:emailData.Full_name,
          User_email_id:emailData.User_email_id,
          Phone:emailData.Phone,
          Report_name:emailData.Report_name,
          Report_license:emailData.Report_license,
          Report_price:emailData.Report_price,
          Creation_date:emailData.Creation_date,
          payment_mode:payment_mode
        };
        const htmlToSend = template(replacements);
        const transporter = nodemailer.createTransport({
          host: 'smtp.protocol',
    port: 587,
    auth: {
        user: 'van1mail',
        pass: 'XuUCGywgAt5QBUTWfQ'
    }
        });
        const mailOptions = {
          from: toEmail,
          to: fromEmail,
          subject: subject,
          html: htmlToSend
        };
        const info = await transporter.sendMail(mailOptions);
      
      };

      email.sendEmailForSampleRequest = async function  sendEmail (toEmail,fromEmail, subject,emailData) {
        const filePath = path.join(__dirname, '../templates/purchase_email.html');
        const source = fs.readFileSync(filePath, 'utf-8').toString();
        const template = handlebars.compile(source);
        const replacements = {
          Full_name:emailData.Full_name,
          User_email_id:emailData.User_email_id,
          Phone:emailData.Phone,
          Report_name:emailData.Report_name,
          Report_license:emailData.Report_license,
          Creation_date:emailData.Creation_date
        };
        const htmlToSend = template(replacements);
        const transporter = nodemailer.createTransport({
          host: 'smtp.protocol',
    port: 587,
    auth: {
        user: 'van1mail',
        pass: 'XuUCGywgAt5QBUTWfQ'
    }
        });
        const mailOptions = {
          from: toEmail,
          to: fromEmail,
          subject: subject,
          html: htmlToSend
        };
        const info = await transporter.sendMail(mailOptions);
      
      };

 module.exports = email

