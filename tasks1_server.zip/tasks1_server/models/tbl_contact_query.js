const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('tbl_contact_query', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
        },
    first_name: {
          type: DataTypes.STRING(250),
          allowNull: false
        },
    last_name: {
          type: DataTypes.STRING(250),
          allowNull: false
        },
    contact: {
          type: DataTypes.STRING(250),
          allowNull: false
        },
    time_slot: {
         type: DataTypes.STRING(250),
          allowNull: false
        },
    created_at: {
          type: DataTypes.DATE,
          allowNull: false
        }
  }, {
    sequelize,
    tableName: 'tbl_contact_query',
    timestamps: false,
    indexes: [
      {
        name: "PRIMARY",
        unique: true,
        using: "BTREE",
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
