var DataTypes = require("sequelize").DataTypes;

var _tbl_contact_query = require("./tbl_contact_query");


function initModels(sequelize) {
  var tbl_contact_query = _tbl_contact_query(sequelize, DataTypes);
  
  return {
    tbl_contact_query

  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
