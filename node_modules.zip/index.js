var express = require('express');
var fs = require('fs');
var path = require('path');
var cookieParser = require('cookie-parser');
var multer  =   require('multer');  
var bodyParser=require('body-parser');
var mysql = require('mysql2');
var app =express();
var nodemailer = require('nodemailer');
var cors= require("cors");
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('/', function (req, res) {  
   res.send('Welcome to ArjunDeep');  
});



app.post('/insert',function(req,res){
  var db=req.body;
  var mysql = require('mysql2');  
  var con = mysql.createConnection({  
  host: "localhost",  
  user: "root",  
  password: "",  
  database: "techrel_db"  
  });  
  console.log(db);
  con.connect(function(err) {  
  if (err) throw err;  
  console.log("Connected!");  

  var sql = `INSERT INTO student_table ( name, email, mobile) VALUES ( '${db.name}','${db.email}','${db.phone}')`;  
  con.query(sql, function (err, result) {  
  if (err) throw err;  
  console.log("1 record inserted");  
  });  
  });
})

///locaholst:8000/delete  new delet
app.post('/delete', function (req, res) {  
   var mysql = require('mysql2');  
    var con = mysql.createConnection({  
    host: "localhost",  
    user: "root",  
    password: "",  
    database: "techrel_db"  
    });  
 var dd=req.body;
    console.log("body data");
      console.log(dd);
       console.log("body data");

    con.connect(function(err) {  
    if (err) throw err;  
    var sql = `DELETE FROM student_table WHERE id ='${dd.id}'`;  
    con.query(sql, function (err, result) {  
    if (err) throw err;  
    console.log("Number of records deleted: " + result.affectedRows);  
    });  
    });  
}) 

///localhost:8000/select
app.get('/select', function (req, res) {  
   var mysql = require('mysql2');  
    var con = mysql.createConnection({  
    host: "localhost",  
    user: "root",  
    password: "",  
    database: "techrel_db"  
    });  
    con.connect(function(err) {  
    if (err) throw err;  
    con.query("SELECT * FROM student_table", function (err, result) {  
    if (err) throw err;  
    console.log(result); 
     res.send(result); 
    });  
    });    
})  


app.post('/oneRd', function (req, res) {  
  var mysql = require('mysql');  
    var con = mysql.createConnection({  
    host: "localhost",  
    user: "root",  
    password: "",  
    database: "techrel_db"  
    });  
    var dd=req.body;
    con.connect(function(err) {  
    if (err) throw err;  
    con.query(`SELECT * FROM student_table WHERE id = '${dd.id}'`, function (err, result) {  
    if (err) throw err;  
    res.send(result);   
    });  
    });     
}) 

app.post('/update', function (req, res) {  
  var mysql = require('mysql2');  
  var con = mysql.createConnection({  
  host: "localhost",  
  user: "root",  
  password: "",  
  database: "techrel_db"  
  });  
  var db=req.body;
  con.connect(function(err) {  
  if (err) throw err;  
  var sql = `UPDATE student_table SET email = '${db.email}',name = '${db.name}' ,mobile = '${db.phone}' WHERE id = '${db.id}'`;  
  con.query(sql, function (err, result) {  
  if (err) throw err;  
  console.log(result.affectedRows + " record(s) updated");  
  });  
  });  
})  

app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET , PUT , POST , DELETE");
    res.header("Access-Control-Allow-Headers", "Content-Type, x-requested-with");
    next(); // Important
});
//
var server = app.listen(8000, function(req,res){  
var host = server.address().address;  
  var port = server.address().port;  
 console.log("Example app listening at http://%s:%s", host, port);  
}); 