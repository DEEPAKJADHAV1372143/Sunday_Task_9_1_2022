import { AllListComponent } from './all-list/all-list.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { SlotTimeComponent } from './slot-time/slot-time.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SlotFormComponent } from './slot-form/slot-form.component';

const routes: Routes = [
  {path:'',component:SlotTimeComponent},
  {path:'form/:id',component:SlotFormComponent},
  {path:'update/:id',component:UpdateUserComponent},
  {path:'list',component:AllListComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
