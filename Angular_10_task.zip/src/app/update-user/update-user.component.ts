import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {
 

  constructor(private formBuilder: FormBuilder,private api:ApiService ,
    private activeRoute:ActivatedRoute, private route:Router) { }
    single_data: any;
   form: any;
   submitted = false;
 ngOnInit(): void {
  this.api.Single_data(this.activeRoute.snapshot.params.id).subscribe((res)=>{
    this.single_data=res;
  })
   window.scrollTo(0, 0);
   this.form = this.formBuilder.group({
   id:[''],
   first_name: ['', Validators.required],
   last_name: ['', Validators.required],
   contact: ['', Validators.required],
   time_slot:[''],
 });
 }
 get f() { return this.form.controls; }

 onSubmit() {
     this.submitted = true;
     if (this.form.invalid) {
         return;
     }
     console.log(this.form.value);
     this.api.Update_data(this.form.value).subscribe((res)=>{
      this.route.navigate(['list']);
      });
    // window.location.reload();
   }

}
