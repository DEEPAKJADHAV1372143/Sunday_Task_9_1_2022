import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-slot-form',
  templateUrl: './slot-form.component.html',
  styleUrls: ['./slot-form.component.css']
})
export class SlotFormComponent implements OnInit {

  
  constructor(private formBuilder: FormBuilder,private api:ApiService ,
    private activeRoute:ActivatedRoute, private route:Router) { }

   form: any;
   submitted = false;
  
   
 ngOnInit(): void {
   window.scrollTo(0, 0);
   this.form = this.formBuilder.group({
   first_name: ['', Validators.required],
   last_name: ['', Validators.required],
   contact: ['', Validators.required],
   time_slot:[this.activeRoute.snapshot.params.id],
 });
 }
 get f() { return this.form.controls; }

 onSubmit() {
     this.submitted = true;
     if (this.form.invalid) {
         return;
     }
     console.log(this.form.value);
     this.api.Submit_document(this.form.value).subscribe((res)=>{
       alert("Your Data is Successfully Submited .");
       window.location.reload();
      });
    // window.location.reload();
   }

}
