import { Router, Routes } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slot-time',
  templateUrl: './slot-time.component.html',
  styleUrls: ['./slot-time.component.css']
})
export class SlotTimeComponent implements OnInit {

  constructor( private route:Router) { }

  ngOnInit(): void {
  }
  form(id:string){
     this.route.navigate(['/form',id]);
  }
}
