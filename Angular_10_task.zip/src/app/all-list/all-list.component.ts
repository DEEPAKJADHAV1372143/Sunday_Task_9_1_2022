import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-all-list',
  templateUrl: './all-list.component.html',
  styleUrls: ['./all-list.component.css']
})
export class AllListComponent implements OnInit {
  all_data: any;

  constructor(private formBuilder: FormBuilder,private api:ApiService ,
    private activeRoute:ActivatedRoute, private route:Router) { }

  ngOnInit(): void {
    this.api.Candidate_data().subscribe((res)=>{
      this.all_data=res;
    });
  }
  Edit(id:string){
    this.route.navigate(['update',id]);
  }
  Delete(id:number){
    this.api.delete_data(id).subscribe((res)=>{
     
    });
    window.location.reload();
  }


}
