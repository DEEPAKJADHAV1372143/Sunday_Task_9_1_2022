import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http:HttpClient) { }
  url2:any="http://localhost:8000/";    
  
  Submit_document(data:any){
    return this.http.post(this.url2+"tbl_contact_query",data);
  }
  Candidate_data(){
    return this.http.get(this.url2+"tbl_contact_query");
  }
  Single_data(id:number){
    return this.http.get(this.url2+"tbl_contact_query/"+id);
  }
  delete_data(id:number){
    return this.http.get(this.url2+"tbl_contact_query_del/"+id);
  }
  Update_data(data:any){
    return this.http.post(this.url2+"tbl_contact_query_updated",data);
  }

}
